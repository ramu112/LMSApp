angular.module('configurations', [])
.constant('API_VERSION','/LMS/api/v1');
